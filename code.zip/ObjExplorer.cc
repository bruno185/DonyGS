
/*
 * ============================================================================
 *              OBJExplorer.cc - Fixed32 Optimized Implementation
 * ============================================================================
 *
 * Purpose:
 *   High-performance Apple IIGS 3D OBJ viewer and explorer implementing the painter's family
 *   of algorithms with multiple painter modes (FAST / FIXED / CORRECT / CORRECTV2).
 *   Reads simplified OBJ files (vertices "v" and faces "f"), transforms them into observer space,
 *   projects to 2D screen coordinates and renders filled polygons.
 *
 * Highlights :
 *   - Target: Apple IIGS (ORCA/C, QuickDraw)
 *   - Painter modes:
 *       * FAST  : z_mean + bbox tests (very fast, less robust)
 *       * FIXED : full fixed-point Newell/Sancha implementation with pairwise
 *                 tests and corrections (robust)
 *       * GEO   : Geometry-only painter mode for heuristic plane-based ordering
 *       * CORRECT : Advanced ordering correction with local face reordering
 *       * CORRECTV2 : Experimental local correction (painter_correctV2) for
 *                   pathological cases
 *   - Z-Buffer scanline rendering implémented

 * Responsibilities (per-frame):
 *   - Transform vertices (Fixed32) to observer-space (xo/yo/zo).
 *   - Project to integer screen coordinates (x2d/y2d).
 *   - Compute per-face metrics: z_min/z_max/z_mean, bbox, plane coefficients.
 *   - Dispatch to the selected painter to populate `sorted_face_indices`.
 *   - Provide tools to inspect and debug the rendering process, 
 *     including visual overlays for inconclusive face pairs and timing instrumentation.
 *
 *
 * Author: Bruno
 * Date: programming started in january 2026
 * ============================================================================
 */

// ==============================================================
// MAIN PROGRAM
// ==============================================================
//
#pragma memorymodel 1
#pragma optimize 1

#include "engine.c"


segment "main";
    int main() {
        Model3D* model = NULL;
        ObserverParams params;
        char filename[100];
        // char input[50];
        int colorpalette = 0; // default color palette
        long last_process_time_start = 0;
        long last_process_time_end = 0;
        long last_ZB_FS_render_time = 0;
        long last_ZB_SL_render_time = 0;
        int show_inconclusive = 0; // toggle: display inconclusive pair overlays (press 'i' to toggle)

        int  oa; // Open-Apple key status
        

        // Initialize the screen save/restore buffer
        if (!initScreenSaveBuffer()) {
            printf("Error: Unable to initialize screen save buffer\n");
            keypress(); // wait for user input before exiting
            destroyModel3D(model);
            return 1;
        }

    newmodel:
        {
            const char* title = "3D OBJ file explorer (version 1.0)";
            int title_len = sizeof("3D OBJ file explorer (version 1.0)") - 1;
            int total_width = 80;
            int border_len = title_len + 6;
            if (border_len > total_width) border_len = total_width;
            int border_pad = (total_width - border_len) / 2;
            int title_pad = (total_width - title_len) / 2;
            char border[81];
            for (int i = 0; i < border_len; ++i) border[i] = '=';
            border[border_len] = '\0';
            printf("%*s%s\n", border_pad, "", border);
            printf("%*s%s\n", title_pad, "", title);
            printf("%*s%s\n\n", border_pad, "", border);
        }
        printf("A tribute to Robert DONY\n");
        printf("Author of \"Calcul des parties cachees\" (Masson, 1986)\n\n");

        // Creer le modele 3D
        model = createModel3D();
        if (model == NULL) {
            printf("Error: Unable to allocate memory for 3D model\n");
            printf("Press any key to quit...\n");
            keypress();
            ZBuffer_Shutdown();
            Offscreen_Shutdown();
            return 1;
        }

        /* Initialize global projection scale to a sensible default (pixels per projected unit) */
        s_global_proj_scale_fixed = INT_TO_FIXED(100);

        // Initialize inconclusive pairs counter
        inconclusive_pairs_count = 0; // clear inconclusive pairs

        // Initialize palettes and palette table storage
        initPalettes();

        int zresult =ZBuffer_Init();
        // printf("ZBuffer_Init result: %d\n", zresult);
        // printf ("zbuf_row[0] = %p\n", zbuf_row[0]);
        // printf ("zbuf_row[199] = %p\n", zbuf_row[199]);
        // keypress(); // wait for user input after initializing Z-buffer
    
        /* Initialize offscreen render buffer (optional) */
        if (!Offscreen_Init()) {
            /* non-fatal: continue without offscreen support */
            // printf("Warning: Offscreen buffer init failed, continuing\n");
        }
    

        // Ask for filename (loop until a non-empty filename is entered and the model loads)
        while (1) {
            printf("Enter the filename to read (ENTER to exit): ");
            if (fgets(filename, sizeof(filename), stdin) != NULL) {
                size_t len = strlen(filename);
                if (len > 0 && filename[len-1] == '\n') {
                    filename[len-1] = '\0';
                }
            } else {
                // EOF or input error - exit gracefully
                printf("\nInput error or EOF. Exiting.\n");
                destroyModel3D(model);
                ZBuffer_Shutdown();
                Offscreen_Shutdown();
                return 1;
            }

            if (filename[0] == '\0') {
                printf("No filename entered. Exiting.\n");
                destroyModel3D(model);
                ZBuffer_Shutdown();
                Offscreen_Shutdown();
                return 0; // Exit program when user presses ENTER with empty filename
            }

            // Try to load the model; if it fails, inform the user, reset model state, and re-prompt
            if (loadModel3D(model, filename) < 0) {
                // Retry once with a ".obj" extension appended, so the user
                // can type the filename without the extension
                size_t flen = strlen(filename);
                int already_has_ext = (flen >= 4 && strcmp(filename + flen - 4, ".obj") == 0);
                int retry_failed = 1;

                if (!already_has_ext) {
                    char filename_ext[256];
                    if (flen + 4 < sizeof(filename_ext)) {
                        snprintf(filename_ext, sizeof(filename_ext), "%s.obj", filename);
                        destroyModel3D(model);
                        model = createModel3D();
                        if (model == NULL) {
                            printf("Error: Unable to allocate memory for 3D model after failed load. Exiting.\n");
                            printf("Press any key to quit...\n");
                            keypress();
                            ZBuffer_Shutdown();
                            Offscreen_Shutdown();
                            return 1;
                        }
                        if (loadModel3D(model, filename_ext) >= 0) {
                            retry_failed = 0;
                        }
                    }
                }

                if (retry_failed) {
                    printf("\nError loading file '%s'. Please try again.\n", filename);
                    // Destroy and recreate model to ensure clean state for next attempt
                    destroyModel3D(model);
                    model = createModel3D();
                    if (model == NULL) {
                        printf("Error: Unable to allocate memory for 3D model after failed load. Exiting.\n");
                        printf("Press any key to quit...\n");
                        keypress();
                        ZBuffer_Shutdown();
                        Offscreen_Shutdown();
                        return 1;
                    }
                    continue;
                }
            }
            // Successfully loaded; ask the user about the overlap scan
            printf("\nPerform 3D face intersection check? (y/N) ");
            fflush(stdout);
            int cc = getchar();
            int reply = cc; /* remember first character */
            while (cc != '\n' && cc != EOF) cc = getchar();
            if (reply == 'y' || reply == 'Y') {
                check_intersect(model);
            }
            break;
        }

        // Initialize observer params defaults and apply auto-fit at load when available
        params.angle_h = 30; params.angle_v = 20; params.angle_w = 0;
        if (model != NULL && model->auto_fit_ready) {
            params.distance = model->auto_suggested_distance;
            model->auto_proj_scale = model->auto_suggested_proj_scale;
            s_global_proj_scale_fixed = model->auto_suggested_proj_scale; // sync global scale
            model->auto_fit_applied = 1;
            printf("Auto-fit applied at load (distance=%.4f proj_scale=%.2f)\n", FIXED_TO_FLOAT(model->auto_suggested_distance), FIXED_TO_FLOAT(model->auto_suggested_proj_scale));

            // Normalize the auto-fit so that the observer distance becomes 150
            // (keeps the apparent size unchanged by scaling vertices + projection scale)
            normalizeAutoFitDistanceTo150(model);
            // Ensure the observer distance used for rendering matches the normalized distance
            params.distance = model->auto_suggested_distance;
        } else {
            params.distance = FLOAT_TO_FIXED(30.0);
        }
        // Get observer parameters (user can override defaults by typing values)
        getObserverParams(&params, model);


    bigloop:
        /*
         * Painters 3, 4 and 5 may use QuickDraw region operations during
         * sorting. Start QuickDraw II without calling startgraph(), so the
         * progress messages remain visible on the text screen.
         *
         * Shut QuickDraw down before startgraph() opens the rendering screen.
         */
        {
            Handle qd_dp = NULL;
            Word qd_id = 0;
            Word qd_err = 0;
            int qd_started = 0;
            int needs_qd = (painter_mode == PAINTER_MODE_NEWELL_SANCHA ||
                            painter_mode == PAINTER_MODE_GEO ||
                            painter_mode == PAINTER_MODE_GEOV3);

            if (needs_qd && !framePolyOnly) {
                qd_id = userid();
                qd_dp = NewHandle(0x300L, qd_id, 0xC015, NULL);
                qd_err = toolerror();
                if (qd_dp == NULL || qd_err != 0) {
                    printf("QuickDraw direct-page allocation failed: $%04X\n", qd_err);
                    if (qd_dp != NULL) DisposeHandle(qd_dp);
                    destroyModel3D(model);
                    ZBuffer_Shutdown();
                    Offscreen_Shutdown();
                    return 1;
                }

                QDStartUp((Word)*qd_dp, 0, mode320, qd_id);
                qd_err = toolerror();
                if (qd_err != 0) {
                    printf("QDStartUp failed: $%04X\n", qd_err);
                    DisposeHandle(qd_dp);
                    destroyModel3D(model);
                    ZBuffer_Shutdown();
                    Offscreen_Shutdown();
                    return 1;
                }
                qd_started = 1;
                shroff();
            }

            /* Exclude temporary QuickDraw startup/shutdown from sorting time. */
            last_process_time_start = GetTick();
            printf("Processing model...\n");
            processModelFast(model, &params, filename);
            last_process_time_end = GetTick();

            if (qd_started) {
                QDShutDown();
                qd_err = toolerror();
                DisposeHandle(qd_dp);
                if (qd_err != 0) {
                    printf("QDShutDown failed: $%04X\n", qd_err);
                    destroyModel3D(model);
                    ZBuffer_Shutdown();
                    Offscreen_Shutdown();
                    return 1;
                }
            }
        }

    loopReDraw:
        {
        int key = 0;
        int r = 0;

        if (model->faces.face_count > 0) {
            // Initialize QuickDraw
            startgraph(mode);

            // Load the system palette into palettes[0] on first startup
            if (!palette0_loaded) {
                palettes[0] = ReadPalette(0);
                palette0_loaded = 1;
            }

            // Apply the selected palette and draw the 3D object
            applyPalette(palette);

            draw:
            if (jitter) drawPolygons_jitter(model, model->faces.vertex_count, model->faces.face_count, model->vertices.vertex_count); 
            // draw model, according to current faces sorted list.
            else drawPolygons(model, model->faces.vertex_count, model->faces.face_count, model->vertices.vertex_count);
            
            // display available colors
            if (colorpalette == 1) { 
                DoColor(); 
            }

            // If there are inconclusive pairs and display is enabled, underline them on screen
            if (show_inconclusive && inconclusive_pairs_count > 0) {
                frameInconclusivePairs(model);  
            }
            // Wait for key press and get key code

        getakey: 
        r = getkeypress_openA(); // Get a key press and the Open-Apple status
        key   = r & 0x00FF;
        oa = (r >> 8) & 1;   // 1 if Open-Apple was pressed

        // these are the commands that are handled immediately without re-rendering the scene
        switch (key) {
            case '*': // Space key
                MoveTo(3, 10);
                saveNextScreenshot(); // save image to file here
                goto getakey; // return to key press handling after saving screenshot, without re-rendering the scene
            case 'G': // Cycle through palettes
            case 'g':
                palette = (palette + 1) % 16; // Cycle through available palettes
                applyPalette(palette);
                goto getakey; // return to key press handling after changing palette, without re-rendering the scene
                break;
            
            case '>':
                // saveScreen(); // save image to file here
                screen2Black();
                int c;
                if (user_fill_color < 0) c = COL_FILL_DEFAULT; // Ensure a valid initial color index
                else 
                c = user_fill_color;
                c = colorChooser(0, &palette, c);
                if (c >= 0) user_fill_color = c;
                if (c == 16) {generate_random_colors(model->faces.face_count);}
                // XXX
                screen2Black();
                goto draw;

            case '<':
                screen2Black();
                c = user_frame_color;
                if (c < 0) c = COL_FRAME; // Ensure a valid initial color index
                c = colorChooser(1, &palette, c);
                if (c >= 0) user_frame_color = c;
                if (c == 16) {generate_random_colors(model->faces.face_count);}
                screen2Black();
                goto draw;
            
            // default:  // All other keys - redraw
            //     goto loopReDraw;
        }

// XXX    
        // This commands just need to swap between text and graphical view (model or colors are unchanged)
        // So saving and restoring screen memory is more efficient than re-rendering the entire scene.
        if (key == ' ' || key == 'H' || key == 'h'|| key == 'F'|| key == 'f'|| key == 'M' 
            || key == 'm'|| key == 'O' || key == 'o' || key == 'U' || key == 'u') {
        saveScreen(); // Save the current screen memory before switching to text view
        // see below what these keys do after saving the screen memory
        }

        endgraph();         // Close QuickDraw
        DoText();           // Show text screen
        }

        
        // Handle keyboard input with switch statement
        switch (key) {
            case 32:  // Space bar - display info and redraw
                printf("===================================\n");
                printf(" Model information and parameters\n");
                printf("===================================\n");
                printf("Model: %s\n", filename);
                printf("Vertices: %d, Faces: %d\n", model->vertices.vertex_count, model->faces.face_count);
                printf("Observer Parameters:\n");
                printf("    Distance: %.2f\n", FIXED_TO_FLOAT(params.distance));
                printf("    Horizontal Angle: %d deg\n", params.angle_h);
                printf("    Vertical Angle: %d deg\n", params.angle_v);
                printf("    Screen Rotation Angle: %d deg\n", params.angle_w);
                printf("    Projection scale: %.2f\n", FIXED_TO_FLOAT(s_global_proj_scale_fixed));
                if (painter_mode == PAINTER_MODE_FAST) printf("    Painter mode: FAST (simple face sorting only)\n");
                else if (painter_mode == PAINTER_MODE_BUBBLE_SORT) printf("    Painter mode: BUBBLE SORT (Fixed32/64)\n");
                else if (painter_mode == PAINTER_MODE_NEWELL_SANCHA) printf("    Painter mode: NEWELL SANCHA (full tests, Fixed32/64)\n");
                else if (painter_mode == PAINTER_MODE_CORRECT) printf("    Painter mode: CORRECT (painter_correct)\n");
                else if (painter_mode == PAINTER_MODE_GEO) printf("    Painter mode: GEO (geometry-only)\n");
                else if (painter_mode == PAINTER_MODE_CORRECTV2) printf("    Painter mode: CORRECT V2 (painter_correctV2 with face splitting detection)\n");
                else if (painter_mode == PAINTER_MODE_GEOV3) printf("    Painter mode: GEO V3 (see R. Dony book, without face splitting)\n");
                else printf("    Painter mode: FLOAT (float-based)\n\n");
                printf("    Back-face culling: %s\n", cull_back_faces ? "ON" : "OFF");
                printf("    Pan offset: (%d, %d)\n", pan_dx, pan_dy);
                if (shaded_by_orientation) printf("    Shading mode: orientation-based\n");
                if (user_fill_color == 16) printf("    Fill color: Random\n");
                else if (user_fill_color >= 0) printf("    Fill color: %d\n", user_fill_color);
                else printf("    Fill color: Default (COL_FILL_DEFAULT (#14))\n");
                if (user_frame_color == 16) printf("    Frame color: Random\n");
                else if (user_frame_color >= 0) printf("    Frame color: %d\n", user_frame_color);
                else printf("    Frame color: Default (COL_FRAME (#7))\n");
                printf ("Processing time: %ld ticks (1/60 sec.)\n", last_process_time_end - last_process_time_start);
                printf("Last Z-Buffer fullscreen render time: %ld ticks\n", last_ZB_FS_render_time);
                printf("Last Z-Buffer scanline render time: %ld ticks\n", last_ZB_SL_render_time);
                printf("===================================\n");
                printf("\n");
                printf("Free memory = %lu bytes\n", FreeMem());
                printf("Press any key to continue...\n");
                keypress();
                // New approach: instead of re-rendering the entire scene, 
                // we save the screen state before switching views and restore it afterward.
                startgraph(mode);   // Reopen QuickDraw and SHGR screen
                restoreScreen();    // Restore the previously saved screen memory
                goto getakey; // return to key press handling
                // This mush faster than re-rendering the entire scene with 
                //goto loopReDraw;

            case 59: // ';' - Run check_sort_repair (repair ordering) and wait for key so user can read results
                printf("Running check_sort_repair (ray_cast verification & minimal repair)...\n");
                check_sort_repair(model, model->faces.face_count);
                printf("Press any key to continue...\n");
                keypress();
                goto loopReDraw;

            case 46: // '.' - Run check_sort_repair_fast (faster minimal repair using QD centroid)
                printf("Running check_sort_repair_fast (QD centroid + minimal repair)...\n");
                check_sort_repair_fast(model, model->faces.face_count);
                // printf("Press any key to continue...\n");
                // keypress();
                goto loopReDraw;

            case 43:  // '+' - increase projection scale by 10% (applies to current scale)
                if (model != NULL) {
                    // '+' now adjusts projection scale by +10%
                    // Compute new scale = current scale * 1.1 (fixed-point multiplication)
                    Fixed32 cur = s_global_proj_scale_fixed;
                    Fixed32 mul = FLOAT_TO_FIXED(1.1f);
                    Fixed32 new_scale = FIXED_MUL_64(cur, mul);
                    // clamp
                    Fixed32 min_scale = FLOAT_TO_FIXED(1.0f);
                    Fixed32 max_scale = FLOAT_TO_FIXED(10000.0f);
                    if (new_scale < min_scale) new_scale = min_scale;
                    if (new_scale > max_scale) new_scale = max_scale;
                    s_global_proj_scale_fixed = new_scale;
                    // sync to model field for visibility
                    model->auto_proj_scale = s_global_proj_scale_fixed;
                    model->auto_fit_applied = 1; // treat scale as explicitly set
                    printf("Projection scale increased -> %.2f\n", FIXED_TO_FLOAT(s_global_proj_scale_fixed));
                } else {
                    printf("No model loaded.\n");
                }
                compute2DFromObserver(model, params.angle_w);
                goto loopReDraw;

            case 45:  // '-' - decrease projection scale by 10% (applies to current scale)
                if (model != NULL) {
                    // '-' now adjusts projection scale by -10%
                    Fixed32 cur = s_global_proj_scale_fixed;
                    Fixed32 mul = FLOAT_TO_FIXED(0.9f);
                    Fixed32 new_scale = FIXED_MUL_64(cur, mul);
                    Fixed32 min_scale = FLOAT_TO_FIXED(1.0f);
                    Fixed32 max_scale = FLOAT_TO_FIXED(10000.0f);
                    if (new_scale < min_scale) new_scale = min_scale;
                    if (new_scale > max_scale) new_scale = max_scale;
                    s_global_proj_scale_fixed = new_scale;
                    model->auto_proj_scale = s_global_proj_scale_fixed;
                    model->auto_fit_applied = 1;
                    printf("Projection scale decreased -> %.2f\n", FIXED_TO_FLOAT(s_global_proj_scale_fixed));
                } else {
                    printf("No model loaded.\n");
                }
                compute2DFromObserver(model, params.angle_w);
                goto loopReDraw;

            case 65:  // 'A' - decrease distance
            case 97:  // 'a'
                if (!oa) params.distance = params.distance - (params.distance / 10);
                else params.distance = params.distance - (params.distance / 2);
                printf("Distance decreased -> %.2f\n", FIXED_TO_FLOAT(params.distance));
                goto bigloop;

            case 90:  // 'Z' - increase distance  
            case 122: // 'z'
                if (!oa) params.distance = params.distance + (params.distance / 10);
                else params.distance = params.distance + (params.distance / 2);
                printf("Distance increased -> %.2f\n", FIXED_TO_FLOAT(params.distance));
                goto bigloop;

            case 21:  // Right arrow - increase horizontal angle
                if (oa == 0) {
                    params.angle_h = normalize_deg(params.angle_h + 10);
                } else {
                    params.angle_h = normalize_deg(params.angle_h + 1);
                }
                goto bigloop;

            case 8:   // Left arrow - decrease horizontal angle
                if (oa == 0) {
                    params.angle_h = normalize_deg(params.angle_h - 10);
                } else {
                    params.angle_h = normalize_deg(params.angle_h - 1);
                }
                goto bigloop;

            case 10:  // Down arrow - decrease vertical angle
                if (oa == 0) {
                    params.angle_v = normalize_deg(params.angle_v - 10);
                } else {
                    params.angle_v = normalize_deg(params.angle_v - 1);
                }
                goto bigloop;

            case 11:  // Up arrow - increase vertical angle
                if (oa == 0) {
                    params.angle_v = normalize_deg(params.angle_v + 10);
                } else {
                    params.angle_v = normalize_deg(params.angle_v + 1);
                }
                goto bigloop;

            case 87:  // 'W' - increase screen rotation angle
            case 119: // 'w'
                if (oa == 0) {
                    params.angle_w = normalize_deg(params.angle_w + 10);
                } else {
                    params.angle_w = normalize_deg(params.angle_w + 1);
                }
                goto bigloop;

            case 88:  // 'X' - decrease screen rotation angle
            case 120: // 'x'
                if (oa == 0) {
                    params.angle_w = normalize_deg(params.angle_w - 10);
                } else {
                    params.angle_w = normalize_deg(params.angle_w - 1);
                }
                goto bigloop;

            /* 2D panning: E=left, R=right (R replaced revert), T=up, Y=down (and lowercase) */
            case 69: /* 'E' */
            case 101: /* 'e' */
                if (!oa) pan_dx -= 10; /* pan left */
                else pan_dx -= 1; /* pan left */
                printf("Pan offset -> (%d,%d)\n", pan_dx, pan_dy);
                goto loopReDraw;

            case 82:  // 'R' - pan right (was revert; revert disabled)
            case 114: // 'r'
                if (!oa) pan_dx += 10; // move right by 10 pixels
                else pan_dx += 1; // move right by 1 pixel
                printf("Pan offset -> (%d,%d)\n", pan_dx, pan_dy);
                goto loopReDraw;


            case 84: /* 'T' */
            case 116: /* 't' */
                if (!oa) pan_dy -= 10; /* pan up = decrease Y */
                else pan_dy -= 1; /* pan up = decrease Y */
                printf("Pan offset -> (%d,%d)\n", pan_dx, pan_dy);
                goto loopReDraw;

            case 89: /* 'Y' */
            case 121: /* 'y' */
                if (!oa) pan_dy += 10; /* pan down = increase Y */
                else pan_dy += 1; /* pan down = increase Y */
                printf("Pan offset -> (%d,%d)\n", pan_dx, pan_dy);
                goto loopReDraw;

            case 48: /* '0' - reset pan */
                pan_dx = 0; pan_dy = 0;
                printf("Pan reset -> (%d,%d)\n", pan_dx, pan_dy);
                goto loopReDraw;
        
            case 67:  // 'C' - toggle color palette display
            case 99:  // 'c'
                colorpalette ^= 1; // Toggle between 0 and 1
                goto loopReDraw;

            case 71:  // 'G' - cycle the active QuickDraw palette
            case 103:  // 'g'
            // replaced by cycling the palette just after key press handling loop

            case 33:  // '!' - toggle orientation shading
                shaded_by_orientation ^= 1;
                printf("Orientation shading: %s\n", shaded_by_orientation ? "ON" : "OFF");
                if (shaded_by_orientation && model != NULL) {
                    computeOrientationShading(model);
                }
                goto loopReDraw;

            case 73:  // 'I' - toggle display of inconclusive face pairs
            case 105: // 'i'
                show_inconclusive ^= 1;
                printf("Inconclusive pairs display: %s\n", show_inconclusive ? "ON" : "OFF");
                goto loopReDraw;

            case 74:  // 'J' - toggle jittered rendering
            case 106: // 'j'
                jitter ^= 1;
                printf("Jitter rendering: %s\n", jitter ? "ON" : "OFF");
                goto loopReDraw;

            case 68:  // 'D' - inspect face ordering and show misplaced faces
            case 100: // 'd'
                if (model == NULL) { printf("No model loaded\n"); goto loopReDraw; }
                inspect_faces_before(model, &params, filename);
                goto loopReDraw;

            case 86:  // 'V' - show a single face in filled mode
            case 118: // 'v'
                if (model == NULL) { printf("No model loaded\n"); goto loopReDraw; }
                showFace(model, &params, filename);
                goto loopReDraw;

            case 83: // 'S' - inspect faces that are AFTER target but should be BEFORE (new)
            case 115: // 's'
                if (model == NULL) { printf("No model loaded\n"); goto loopReDraw; }
                inspect_faces_after(model, &params, filename);
                goto loopReDraw;

            case 77: // 'M' - debug pair_plane_before
            case 109: // 'm'
                if (model == NULL) { printf("No model loaded\n"); goto loopReDraw; }
                pair_plane_geometric_tests(model, -1, -1); // force type pair numbers
			    // New approach: instead of re-rendering the entire scene, 
                // we save the screen state before switching views and restore it afterward.
                startgraph(mode);   // Reopen QuickDraw and SHGR screen
                restoreScreen();    // Restore the previously saved screen memory
                goto getakey; // return to key press handling
                // This mush faster than re-rendering the entire scene with 
                //goto loopReDraw;


            case 76: // 'L' - show model with face ID labels at polygon centers
            case 108: // 'l'
                if (model == NULL) { printf("No model loaded\n"); goto loopReDraw; }
                display_model_face_ids(model, &params, filename);
                goto loopReDraw;

            case 49: // '1' - set FAST painter
                painter_mode = PAINTER_MODE_FAST;
                printf("Painter mode: FAST (simple face sorting only)\n");
                inconclusive_pairs_count = 0; // clear inconclusive pairs in fast mode
                if (model != NULL) { printf("Reprocessing model with current mode...\n"); goto bigloop; }

            case 50: // '2' - set BUBBLE SORT (Fixed32/64) painter
                painter_mode = PAINTER_MODE_BUBBLE_SORT;
                printf("Painter mode: BUBBLE SORT (full tests, Fixed32/64)\n");
                if (model != NULL) { printf("Reprocessing model with current mode...\n"); goto bigloop; }

            case 51: // '3' - set NEWELL SANCHA (Fixed32/64) painter
                painter_mode = PAINTER_MODE_NEWELL_SANCHA;
                printf("Painter mode: NEWELL SANCHA (full tests, Fixed32/64)\n");
                if (model != NULL) { printf("Reprocessing model with current mode...\n"); goto bigloop; }

            case 52: // '4' - set GEO painter
                painter_mode = PAINTER_MODE_GEO;
                printf("Painter mode: GEO (geometry-only)\n");
                printf("WARNING: This mode can be significantly slower than others with large models.\n");
                if (model != NULL) { printf("Reprocessing model with current mode...\n"); goto bigloop; }
            
            case 53: // '5' - set GEO V3 painter
                painter_mode = PAINTER_MODE_GEOV3;
                printf("Painter mode: GEO V3 (inspired by R. DONY's book)\n");
                printf("WARNING: This mode can be significantly slower than others with large models.\n");
                goto bigloop; 
                goto loopReDraw;

            case 54: // '6' - set CORRECT painter (runs painter_correct)
                painter_mode = PAINTER_MODE_CORRECT;
                printf("Painter mode: CORRECT (painter_correct)\n");
                if (model != NULL) { printf("Reprocessing model with current mode...\n"); goto bigloop; }

            case 55: // '7' - set CORRECTV2 painter (runs painter_correctV2 with face splitting detection)
                painter_mode = PAINTER_MODE_CORRECTV2;
                printf("Painter mode: CORRECT V2 (painter_correctV2)\n");
                if (model != NULL) { printf("Reprocessing model with current mode...\n"); goto bigloop; }


            case 56: // '8' - quick random mode for both colors
                user_fill_color = 16;
                // user_frame_color = 16; // uncomment if you want to randomize the frame color as well
                if (model != NULL) {
                    generate_random_colors(model->faces.face_count);
                }
                printf("Colors set to RANDOM mode (new colors generated)\n");
                goto loopReDraw;


            case 57: // '9' - reset colors to default
                user_fill_color = -1;
                user_frame_color = -1;
                palette = 0; // reset to system palette
                shaded_by_orientation = 0; // disable orientation shading
                printf("Colors reset to defaults, palette reset to 0, shading OFF\n");
                goto loopReDraw;


                
            // Z buffer scanline and fullscreen rendering

            case 79:  // 'o' - Render model using scanline Z-buffer
            case 111: // 'o'
                startgraph(mode);
                MoveTo(3, 10);
                printf("Z-Buffer scanline rendering...\n");
                long startTime = GetTick();
                renderModelScanlineZBuffer(model);
                long endTime = GetTick();
                last_ZB_SL_render_time = endTime - startTime;
                goto getakey; // return to key press handling

            case 'U': // 'U' - Render model using fullscreen Z-buffer
            case 'u': 
                startgraph(mode);
                MoveTo(3, 10);
                if (!oa) printf("Z-Buffer fullscreen rendering (offscreen)...\n");
                else printf("Z-Buffer fullscreen rendering (onscreen)...\n");
                startTime = GetTick(); 
                if (!oa) {
                    Offscreen_Clear();
                    renderModelFullscreenZBuffer_offscreen(model);
                    Offscreen_FlushToScreen();
                }
                else {
                    renderModelFullscreenZBuffer(model);
                }

                endTime = GetTick();
                last_ZB_FS_render_time = endTime - startTime;
                goto getakey; // return to key press handling                

            
            case 80:  // 'P' - toggle frame-only polygon rendering
            case 112: // 'p'
                framePolyOnly ^= 1;
                printf("Frame-only polygons: %s\n", framePolyOnly ? "ON" : "OFF");
                if (!framePolyOnly) {
                    // Switched back to filled polygons — re-run full processing to recompute depths & ordering
                    printf("Switching to filled mode: reprocessing model (sorting faces)...\n");
                    goto bigloop;
                }
                else {
                    // Just redraw in frame-only mode
                    goto loopReDraw;
                }

            case 66:  // 'B' - toggle back-face culling (observer-space d<=0 test)
            case 98:  // 'b'
                cull_back_faces ^= 1;
                printf("Back-face culling: %s\n", cull_back_faces ? "ON" : "OFF");
                if (model != NULL) {
                    printf("Reprocessing model with culling %s...\n", cull_back_faces ? "ON" : "OFF");
                    goto bigloop;
                }
                //goto loopReDraw;

            case 70:  // 'F' - dump face equations to equ.csv
            case 102: // 'f'
                if (model != NULL) {
                    printf("Writing files...\n");
                    // Ensure the current observer parameters are applied before dumping
                    // processModelFast(model, &params, filename);
                    // Use semicolon column separators and comma decimal separator
                    dumpFaceEquationsCSV(model, "Faces3D.csv", 1);
                    // Also dump 2D per-face vertex coordinates to Faces2D.txt
                    dumpFace2DCoordinates(model, "Faces2D.txt");
                    // Dump sorted face indices in painter output order
                    dumpSortedFaceIndices(model, "FacesOrder.txt");
                    printf("\nPress any key to continue...\n");
                    keypress();
                }
                // New approach: instead of re-rendering the entire scene, 
                // we save the screen state before switching views and restore it afterward.
                startgraph(mode);   // Reopen QuickDraw and SHGR screen
                restoreScreen();    // Restore the previously saved screen memory
                goto getakey; // return to key press handling
                // This mush faster than re-rendering the entire scene with 
                //goto loopReDraw;

            case 78:  // 'N' - load new model
            case 110: // 'n'
                // Reset all parameters to startup defaults when loading a new model
                painter_mode = PAINTER_MODE_FAST;
                pan_dx = 0; pan_dy = 0;
                cull_back_faces = 1;
                user_fill_color = -1;
                user_frame_color = -1;
                s_global_proj_scale_fixed = INT_TO_FIXED(100);
                jitter = 0; /* reset jitter when loading new model */
                destroyModel3D(model);
                goto newmodel;

            case 75:  // 'K' - edit angles/distance (no reload; ENTER may auto-fit)
            case 107: // 'k'
                getObserverParams(&params, model);
                printf("Observer parameters updated.\n");
                goto bigloop;
        
            // display help (paged)
            case 72:  // 'H'
            case 104: // 'h'
                show_help_pager();
                // New approach: instead of re-rendering the entire scene, 
                // we save the screen state before switching views and restore it afterward.
                startgraph(mode);   // Reopen QuickDraw and SHGR screen
                restoreScreen();    // Restore the previously saved screen memory
                goto getakey; // return to key press handling
                // This mush faster than re-rendering the entire scene with 
                //goto loopReDraw;
                goto loopReDraw;

            case 81: // 'Q' - interactive face-pair inspector (new)
            case 113: // 'q'
                if (model == NULL) { printf("No model loaded\n"); goto loopReDraw; }
                inspect_face_pair_ui(model);
                goto loopReDraw;

            case 47: // '/' - test projected overlap raster
                if (model == NULL) { printf("No model loaded\n"); goto loopReDraw; }
                // test_all_projected_overlaps(model);
                printf("Running projected overlap benchmark...\n");
                // benchmark_projected_overlap(model, &params, 1); // Example with 10 angles
                benchmark_projected_overlap_all(model, &params, 1); // Example with 10 angles
                keypress();
                goto loopReDraw;

                case 40: // '(' - show help (paged)
                overlap_method = select_overlap_method(overlap_method);
                goto bigloop;

            case 27:  // ESC - quit
                goto end;
            


                
            default:  // All other keys - redraw
                goto loopReDraw;
            
        }
        }  // End of loopReDraw block

        end:
        // Cleanup and exit
        // Dispose of the global polygon handle if it was allocated
        if (globalPolyHandle != NULL) {
            if (poly_handle_locked) {
                HUnlock(globalPolyHandle);
            }
            DisposeHandle(globalPolyHandle);
            globalPolyHandle = NULL;
        }
        destroyModel3D(model);
        ZBuffer_Shutdown();
        Offscreen_Shutdown();
        return 0;
    }

